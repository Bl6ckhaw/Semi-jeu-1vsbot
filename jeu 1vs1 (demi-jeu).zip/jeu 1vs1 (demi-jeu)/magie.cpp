#include "magie.h"

using namespace std;

Magie::Magie(): m_nomSort ("Boule de feu"), m_dmgSort(15), m_pointMana(40)
{

}

Magie::Magie(string nomSort, int dmgSort, int pointMana): m_nomSort(nomSort), m_dmgSort(dmgSort), m_pointMana(pointMana)
{

}

void Magie::afficher() const{
    cout << "Sort: " << m_nomSort << "(degats: " << m_dmgSort << ", point de mana utilise:"<< m_pointMana <<")" << endl;
}

int Magie::getDmgSort()const{
    return m_dmgSort;
}
