#ifndef ARME_H_INCLUDED
#define ARME_H_INCLUDED
#include <iostream>
#include <string>

class Arme{

public:
    Arme();//constructeur
    Arme(std::string nom, int dmg);
    void changer(std::string nom, int dmg);
    void afficher()const;
    int getDmg() const;

private:
    std::string m_nom;
    int m_dmg;

};


#endif // ARME_H_INCLUDED
