#ifndef MAGIE_H_INCLUDED
#define MAGIE_H_INCLUDED
#include <iostream>
#include <string>

class Magie{

public:
    Magie();//constructeur
    Magie(std::string nomSort, int dmgSort, int pointMana);
    void afficher()const;
    int getDmgSort() const;

private:
    std::string m_nomSort;
    int m_dmgSort;
    int m_pointMana;

};


#endif // MAGIE_H_INCLUDED
