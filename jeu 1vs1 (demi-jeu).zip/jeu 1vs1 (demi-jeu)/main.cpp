#include <iostream>
#include <string>
#include "personnage.h"

using namespace std;


int main()
{
   /*Personnage david;
   Personnage bob;

   bob.attaquer(david);
   david.boireHealPotion(20);
   bob.attaquer(david);
   david.attaquer(bob);
   bob.changerArme("�p�e de la mort qui tue", 40);
   bob.attaquer(david);

   cout << "David " <<endl;
   david.afficherEtat();
   cout << "Bob" << endl;
   bob.afficherEtat();*/

   int reponse;
   cout << "Boss, vous devez vraincre votre ennemi! ";

   Personnage Boss;
   Personnage Arthur("excalibur", 19);

   cout << "Vous allez combattre quelq'un de terrifiant, ce n'est autre que le guerrier legendaire 'Arthur'" << endl;
   cout << "il arrive vers vous!!!"<<endl;


   do{
        cout << "Quelle action voulez vous faire: "<< endl<<endl<< "Attaque epee (press '1')" << endl << "Attaque magique (press '2')" <<endl<< "Boire une potion de vie (press '3')"<< endl<<endl<< "alors?  ";
        cin >>reponse;

        if (reponse == 1){
            Boss.attaquer(Arthur);
            cout << "vous venez d'attaquer votre adversaire avec 'epee en bois' " << endl<<endl;
            Arthur.attaquer(Boss);
            cout << "Arthur lance une attaque vous subissez des degats"<< endl<<endl;

            cout << "Arthur: ";
            Arthur.afficherEtat();
            cout <<endl<<"Boss: ";
            Boss.afficherEtat();
            cout<< endl<<endl;
        }

        else if (reponse == 2){

            Boss.magie(Arthur, 50);
            cout<< "vous venez d'envoyer un sort: 'Boule de feu' sur le legendaire Arthur"<< endl<<endl;
            cout << "Arthur est etourdi par votre sort"<<endl<<endl;

            cout << "Arthur: ";
            Arthur.afficherEtat();
            cout <<endl<< "Boss: ";
            Boss.afficherEtat();
            cout<< endl<<endl;

        }
        else if (reponse == 3){
            Boss.boireHealPotion(25);
            cout<< "Vous buvez une potion qui vous rend 20 points de vie"<<endl<<endl;
            Arthur.attaquer(Boss);
            cout << "Arthur en profite pour vous attaquer"<< endl<<endl;

            cout << "Arthur: ";
            Arthur.afficherEtat();
            cout <<endl<< "Boss: ";
            Boss.afficherEtat();
            cout<< endl<<endl;
        }
   }while (Boss.estVivant() && Arthur.estVivant());

   cout << "le combat est termine"<< endl;

   if (Boss.estVivant()){
        cout << "vous avez gagne!";
   }
   else if (Arthur.estVivant()){
        cout << "vous avez perdu!";
   }


   return 0;
}
