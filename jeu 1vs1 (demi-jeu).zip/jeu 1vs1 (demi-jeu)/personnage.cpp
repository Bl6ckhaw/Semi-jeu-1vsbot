#include "personnage.h"

using namespace std;

void Personnage::recevoirDegat (int nbrDmg){
    m_vie -= nbrDmg;

    if (m_vie < 0){
        m_vie = 0;
    }
}

void Personnage::attaquer (Personnage &cible){
    cible.recevoirDegat(m_arme.getDmg());
}

void Personnage::magie(Personnage &cible, int pointMana){
        int reponse;
        if (pointMana > m_mana){
            cout << "vous n'avez plus assez de mana" <<endl;
            cout << "choisissez une autre action: ";
            cin>>reponse;
        }
        else{
            cible.recevoirDegat(m_sort.getDmgSort());
            m_mana -= pointMana;
        }

}

void Personnage::boireHealPotion (int quantitePotion){
    m_vie += quantitePotion;

    if (m_vie > 100){
        m_vie = 100;
    }
}

void Personnage::changerArme (string nomNewArme, int dmgNewArme){
    m_arme.changer(nomNewArme, dmgNewArme);
}

bool Personnage::estVivant (){
    return m_vie > 0;
}

void Personnage::afficherEtat(){
    cout << "vie: " << m_vie << endl;
    cout << "mana: " << m_mana << endl;
    m_arme.afficher();
    m_sort.afficher();
}

//Constructeurs -> initialiser les donn�es
Personnage::Personnage(): m_vie(100), m_mana(100)
{

}

Personnage::Personnage(std::string nomArme, int degatArme): m_vie(100), m_mana(100), m_arme(nomArme, degatArme)
{

}

Personnage::~Personnage()
{

}





























