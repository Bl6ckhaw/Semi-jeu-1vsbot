#ifndef PERSONNAGE_H_INCLUDED
#define PERSONNAGE_H_INCLUDED
#include "Arme.h"
#include "magie.h"
#include <iostream>
#include <string>

class Personnage{

    public:
    //M�thode = fonction
    Personnage(); //constructeur
    Personnage(std::string nomArme, int dmgArme);
    ~Personnage();
    void recevoirDegat (int nbrDmg);
    void attaquer (Personnage &cible);
    void boireHealPotion (int quantitePotion);
    void changerArme (std::string nomNewArme, int dmgNewArme);
    bool estVivant();
    void afficherEtat();
    void magie(Personnage &cible, int pointMana);

    private:
    //Attributs = variable
    int m_vie;
    int m_mana;
    Arme m_arme;
    Magie m_sort;
};


#endif // PERSONNAGE_H_INCLUDED
