#include "Arme.h"

using namespace std;

Arme::Arme(): m_nom ("�p�e en bois"), m_dmg(17)
{

}

Arme::Arme(string nom, int dmg): m_nom(nom), m_dmg(dmg)
{

}

void Arme::changer(string nom, int dmg){
    m_nom = nom;
    m_dmg = dmg;
}

void Arme::afficher() const{
    cout << "Arme: " << m_nom << "(degats: " << m_dmg << ")" << endl;
}

int Arme::getDmg()const{
    return m_dmg;
}






